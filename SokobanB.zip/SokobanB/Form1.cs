using System.Media;
using System.Numerics;
using System.Security.Authentication.ExtendedProtection;
using System.Security.Cryptography.X509Certificates;

namespace SokobanB
{
    public partial class Form1 : Form
    {
        class obj
        {
            public int x;
            public int y;
        }
        int[,] pole = new int[12, 30];
        obj player = new obj();
        PictureBox[,] l = new PictureBox[12, 30];
int curlevel = 0;
        int count = 0;
       int level=0; 
        void Level1(int[,] pole, obj player)
        {
            curlevel = 1;
            level = 6;
            pole[9, 12] = 1;
            player.x = 12;
            player.y = 9;

            pole[1, 4] = 3;
            pole[1, 5] = 3;
            pole[1, 6] = 3;
            pole[1, 7] = 3;
            pole[1, 8] = 3;

            pole[2, 4] = 3;
            pole[2, 8] = 3;

            pole[3, 4] = 3;
            pole[3, 8] = 3;
            pole[3, 5] = 2;

            pole[4, 2] = 3;
            pole[4, 3] = 3;
            pole[4, 4] = 3;
            pole[4, 7] = 2;
            pole[4, 8] = 3;
            pole[4, 9] = 3;
            pole[4, 10] = 3;

            pole[5, 5] = 2;
            pole[5, 2] = 3;
            pole[5, 10] = 3;
            pole[5, 8] = 2;

            pole[6, 0] = 3;
            pole[6, 1] = 3;
            pole[6, 2] = 3;
            pole[6, 4] = 3;
            pole[6, 6] = 3;
            pole[6, 7] = 3;
            pole[6, 8] = 3;
            pole[6, 10] = 3;
            pole[6, 16] = 3;
            pole[6, 17] = 3;
            pole[6, 18] = 3;
            pole[6, 19] = 3;
            pole[6, 20] = 3;
            pole[6, 21] = 3;

            pole[7, 0] = 3;
            pole[7, 4] = 3;
            pole[7, 6] = 3;
            pole[7, 7] = 3;
            pole[7, 8] = 3;
            pole[7, 10] = 3;
            pole[7, 11] = 3;
            pole[7, 12] = 3;
            pole[7, 13] = 3;
            pole[7, 14] = 3;
            pole[7, 15] = 3;
            pole[7, 16] = 3;
            pole[7, 19] = 4;
            pole[7, 20] = 4;
            pole[7, 21] = 3;

            pole[8, 0] = 3;
            pole[8, 2] = 2;
            pole[8, 5] = 2;
            pole[8, 19] = 4;
            pole[8, 20] = 4; pole[8, 21] = 3;

            pole[9, 0] = 3;
            pole[9, 1] = 3;
            pole[9, 2] = 3;
            pole[9, 3] = 3;
            pole[9, 4] = 3;
            pole[9, 6] = 3;
            pole[9, 7] = 3;
            pole[9, 8] = 3;
            pole[9, 9] = 3;
            pole[9, 11] = 3;
            pole[9, 13] = 3;
            pole[9, 14] = 3;
            pole[9, 15] = 3;
            pole[9, 16] = 3;
            pole[9, 19] = 4;
            pole[9, 20] = 4;
            pole[9, 21] = 3;


            pole[10, 4] = 3;
            pole[10, 11] = 3;
            pole[10, 12] = 3;
            pole[10, 13] = 3;
            pole[10, 16] = 3;
            pole[10, 17] = 3;
            pole[10, 18] = 3;
            pole[10, 19] = 3;
            pole[10, 20] = 3;
            pole[10, 21] = 3;

            pole[11, 4] = 3;
            pole[11, 5] = 3;
            pole[11, 6] = 3;
            pole[11, 7] = 3;
            pole[11, 8] = 3;
            pole[11, 9] = 3;
            pole[11, 10] = 3;
            pole[11, 11] = 3;



        }

        void Appea(int[,] pole)
        {
            for (int y = 0; y < 12; y++)
            {
                for (int x = 0; x < 30; x++)
                {
                    l[y, x] = new PictureBox();
                   
                    l[y, x].Location = new System.Drawing.Point((x + 8) * 30, (y + 7) * 30);
                    l[y, x].Name = "Label1";
                    l[y, x].AutoSize = false;
                    l[y, x].SizeMode = PictureBoxSizeMode.StretchImage;
                    l[y, x].Size = new System.Drawing.Size(30, 30);
                    if (pole[y, x] == 0) { l[y, x].Image = Image.FromFile("Resources\\" + "\\0.jpg"); }
                    if (pole[y, x] == 1) { l[y, x].Image = Image.FromFile("Resources\\" + "\\1.jpg"); }
                    if (pole[y, x] == 2) { l[y, x].Image = Image.FromFile("Resources\\" + "\\2.jpg"); }
                    if (pole[y, x] == 3) { l[y, x].Image = Image.FromFile("Resources\\" + "\\3.jpg"); }
                    if (pole[y, x] == 4) { l[y, x].Image = Image.FromFile("Resources\\" + "\\4.jpg"); }
                    if (pole[y, x] == 5) { l[y, x].Image = Image.FromFile("Resources\\" + "\\5.jpg"); }
                    if (pole[y, x] == 6) { l[y, x].Image = Image.FromFile("Resources\\" + "\\6.jpg"); }
                    l[y, x].Text = "";
                    Controls.Add(l[y, x]);

                }
            }
        }

      
        void WASDupdate(int[,] pole, obj player, int count, int level) {
            for (int y = player.y - 3;
                    y > player.y - 4 && y < player.y + 4 &&
                    y < 12; y++)
            {
                for (int x = player.x - 3; x > player.x - 4 && x < player.x + 4 && x < 30; x++)
                {
                    if (y >= 0 && x >= 0)
                    {
                        if (pole[y, x] == 0) { l[y, x].Image = Image.FromFile("Resources\\" + "\\0.jpg"); }
                        if (pole[y, x] == 1) { l[y, x].Image = Image.FromFile("Resources\\" + "\\1.jpg"); }
                        if (pole[y, x] == 2) { l[y, x].Image = Image.FromFile("Resources\\" + "\\2.jpg"); }
                        if (pole[y, x] == 3) { l[y, x].Image = Image.FromFile("Resources\\" + "\\3.jpg"); }
                        if (pole[y, x] == 4) { l[y, x].Image = Image.FromFile("Resources\\" + "\\4.jpg"); }
                        if (pole[y, x] == 5) { l[y, x].Image = Image.FromFile("Resources\\" + "\\5.jpg");  }
                        if (pole[y, x] == 6) { l[y, x].Image = Image.FromFile("Resources\\" + "\\6.jpg"); }
                    }
                }
            }




            for (int y=0; y<12; y++)
            {
                for (int x = 0; x < 30; x++)
                {
                   
                    if (pole[y, x] == 5) { count++; }
                   
                }
            }
            //�������� �� ������
            if (level <= count)
            {
                MessageBox.Show("�� �������� ������ ������� �������!");
                Dele();

                Men();
            }
            count = 0;
        }
       




        void Level2(int[,] pole, obj player)
        {
            curlevel = 2;
            level =2;
            
            player.x = 2;
            player.y = 3;
            pole[0, 0] = 3; pole[0, 1] = 3;
            pole[0, 2] = 3; pole[0, 3] = 3; pole[1, 2] = 4;
            pole[1, 0] = 3; pole[1, 3] = 3;
            pole[2, 0] = 3; pole[2, 3] = 3; pole[2, 4] = 3;
            pole[3, 0] = 3; pole[3, 1] = 5; pole[3, 2] = 1; pole[3, 5] = 3;
            pole[4, 0] = 3; pole[4, 3] = 2; pole[4, 5] = 3;
            pole[5, 0] = 3; pole[5, 3] = 3; pole[5, 4] = 3;
            pole[6, 1] = 3; pole[6, 2] = 3;
        }
        void Level3(int[,] pole, obj player)
        {
            curlevel = 3;
            level = 3;

            player.x = 3;
            player.y = 2;
            pole[0, 1] = 3; pole[0, 2] = 3; pole[0, 3] = 3; pole[0, 4] = 3;
            pole[1, 0] = 3; pole[1, 5] = 3;
            pole[2, 0] = 3; pole[2, 5] = 3; pole[2, 2] = 3; pole[2, 3] = 1;
            pole[3, 0] = 3; pole[3, 5] = 3; pole[3, 2] = 2; pole[3, 3] = 5;
            pole[4, 0] = 3; pole[4, 5] = 3; pole[4, 2] = 4; pole[4, 3] = 5;
            pole[5, 0] = 3; pole[5, 5] = 3;
            pole[6, 1] = 3; pole[6, 2] = 3; pole[6, 3] = 3; pole[6, 4] = 3;
        }
        void GenPole(int[,] pole)
            {
                for (int y = 0; y < 12; y++)
                {
                    for (int x = 0; x < 30; x++)
                    {
                        pole[y, x] = 0;

                    }
                }
            }
           
        void Dele( )
        { Controls.Clear(); }

       void Men()
        {
            Label zag = new Label();
            zag = new Label();
            zag.Location = new System.Drawing.Point(650, 180);
            zag.Text = "Sokoban";
            zag.Name = "Label1";
            zag.AutoSize = false;
            zag.BackColor = Color.Gray;
            zag.Size = new System.Drawing.Size(53, 15);
            Controls.Add(zag);






            Label lvls = new Label();
            lvls = new Label();
            lvls.Location = new System.Drawing.Point(650, 200);
            lvls.Text = "������:";
            lvls.Name = "Label1";
            lvls.AutoSize = false;
            lvls.BackColor = Color.Gray;
            lvls.Size = new System.Drawing.Size(53, 15);
            Controls.Add(lvls);

            Button lvl1, lvl2, lvl3, help, exit = new Button();
            lvl1 = new Button();
            lvl2 = new Button();
            lvl3 = new Button();
            help = new Button();
            lvl1.Text = "������� 1";
            lvl1.Click += button1_Click;
            lvl1.Location = new System.Drawing.Point(561, 250);
            lvl2.Text = "������� 2";
            lvl2.Click += button2_Click;
            lvl2.Location = new System.Drawing.Point(642, 250);
            lvl3.Text = "������� 3";
            lvl3.Click += button3_Click;
            lvl3.Location = new System.Drawing.Point(723, 250);
            Controls.Add(lvl1);
            Controls.Add(lvl2);
            Controls.Add(lvl3);
            help.Text = "������";
            help.Click += button4_Click;
            help.Location = new System.Drawing.Point(642, 300);
            Controls.Add(help);


            exit.Text = "�����";
            exit.Click += button5_Click;
            exit.Location = new System.Drawing.Point(642, 350);
            Controls.Add(exit);


            Label Menu = new Label();
            Menu = new Label();
            Menu.Location = new System.Drawing.Point(500, 150);
            Menu.Text = "";
            Menu.Name = "Label1";
            Menu.AutoSize = false;
            Menu.BackColor = Color.Gray;
            Menu.Size = new System.Drawing.Size(362, 390);
            Controls.Add(Menu);
        }

        void mus()
        {
            SoundPlayer s = new SoundPlayer(Convert.ToString(Application.StartupPath) + "\\ve.wav");
            System.Windows.Forms.Timer timer;
            int timerCount = 0;

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000;
            timer.Tick += delegate
            {
                if (timerCount > 0)
                {
                    timerCount--;
                }
                else if (true)
                {
                    timerCount = 129;
                    s.Stop();
                    s.Play();
                }
            };
            timer.Start();
        }
        public Form1()
        {
            InitializeComponent();

            mus();
           

            Men();
            

        }
      

        
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

         








            bool CheckWallPlayerUp(int[,] pole, obj player)
            {
                if (pole[player.y - 1, player.x] == 3) { return false; } else { return true; }
            }

            bool CheckWallPlayerDown(int[,] pole, obj player)
            {
                if (pole[player.y + 1, player.x] == 3) { return false; } else { return true; }
            }

            bool CheckWallPlayerLeft(int[,] pole, obj player)
            {
                if (pole[player.y, player.x - 1] == 3) { return false; } else { return true; }
            }
            bool CheckWallPlayerRight(int[,] pole, obj player)
            {
                if (pole[player.y, player.x + 1] == 3) { return false; } else { return true; }
            }



            void DownBoxMove(int[,] pole, obj player) {


                if (pole[player.y + 1, player.x] == 2 || pole[player.y + 1, player.x] == 5)
                {
                    if (pole[player.y + 2, player.x] != 4) pole[player.y + 2, player.x] = 2;
                    else pole[player.y + 2, player.x] = 5;


                }


            }
            void LeftBoxMove(int[,] pole, obj player)     {


                if (pole[player.y, player.x - 1] == 2 || pole[player.y, player.x - 1] == 5)
                {
                    if (pole[player.y, player.x - 2] != 4) pole[player.y, player.x - 2] = 2;
                    else pole[player.y, player.x - 2] = 5;


                }


            }
            void RightBoxMove(int[,] pole, obj player)    {


                if (pole[player.y, player.x + 1] == 2 || pole[player.y, player.x + 1] == 5)
                {
                    if (pole[player.y, player.x + 2] != 4) pole[player.y, player.x + 2] = 2;
                    else pole[player.y, player.x + 2] = 5;


                }


            }
            void UpBoxMove(int[,] pole, obj player) {


                if (pole[player.y - 1, player.x] == 2 || pole[player.y - 1, player.x] == 5)
                {
                    if (pole[player.y - 2, player.x] != 4) pole[player.y - 2, player.x] = 2;
                    else pole[player.y - 2, player.x] = 5;


                }


            }







            bool CheckTwicePlayerUp(int[,] pole, obj player)  {
                if (pole[player.y - 1, player.x] == 2 || pole[player.y - 1, player.x] == 5)
                {
                    if (pole[player.y - 2, player.x] == 3 ||
                        pole[player.y - 2, player.x] == 2 || pole[player.y - 2, player.x] == 5)
                        return false;
                    else return true;
                }
                else return true;
            }

            bool CheckTwicePlayerDown(int[,] pole, obj player){
                if (pole[player.y + 1, player.x] == 2 || pole[player.y + 1, player.x] == 5)
                {
                    if (pole[player.y + 2, player.x] == 3 ||
                        pole[player.y + 2, player.x] == 2 || pole[player.y + 2, player.x] == 5)
                        return false;
                    else return true;
                }
                else return true;
            }

            bool CheckTwicePlayerLeft(int[,] pole, obj player)   {
                if (pole[player.y, player.x - 1] == 2 || pole[player.y, player.x - 1] == 5)
                {
                    if (pole[player.y, player.x - 2] == 3 ||
                        pole[player.y, player.x - 2] == 2 || pole[player.y, player.x - 2] == 5)
                        return false;
                    else return true;
                }
                else return true;
            }
            bool CheckTwicePlayerRight(int[,] pole, obj player){
                if (pole[player.y, player.x + 1] == 2 || pole[player.y, player.x + 1] == 5)
                {
                    if (pole[player.y, player.x + 2] == 3 ||
                        pole[player.y, player.x + 2] == 2 || pole[player.y, player.x + 2] == 5)
                        return false;
                    else return true;
                }
                else return true;
            }






           
         














            if (e.KeyCode == Keys.W && CheckWallPlayerUp(pole, player) == true && CheckTwicePlayerUp(pole, player) == true) {
                    UpBoxMove(pole, player);


                    if (pole[player.y - 1, player.x] != 5 && pole[player.y - 1, player.x] != 4) pole[player.y - 1, player.x] = 1; else pole[player.y - 1, player.x] = 6;
                    if (pole[player.y, player.x] != 6) pole[player.y, player.x] = 0; else pole[player.y, player.x] = 4;
                    player.y--;



                WASDupdate(pole, player, count, level);
                

            }








            else
                {
                    if (e.KeyCode == Keys.S && CheckWallPlayerDown(pole, player) == true && CheckTwicePlayerDown(pole, player) == true)   {
                        DownBoxMove(pole, player);
                    

                        if (pole[player.y + 1, player.x] != 5 && pole[player.y + 1, player.x] != 4) pole[player.y + 1, player.x] = 1; else pole[player.y + 1, player.x] = 6;//����� ������ ��������
                        if (pole[player.y, player.x] != 6) pole[player.y, player.x] = 0; else pole[player.y, player.x] = 4;
                        player.y++;
                   
                    WASDupdate(pole, player, count, level);
                   


                }
                    else


                    {
                        if (e.KeyCode == Keys.A && CheckWallPlayerLeft(pole, player) == true && CheckTwicePlayerLeft(pole, player) == true)
                        {
                  
                        LeftBoxMove(pole, player);
                            if (pole[player.y, player.x - 1] != 5 && pole[player.y, player.x - 1] != 4) pole[player.y, player.x - 1] = 1; else pole[player.y, player.x - 1] = 6;//����� ������ ��������
                            if (pole[player.y, player.x] != 6) pole[player.y, player.x] = 0; else pole[player.y, player.x] = 4;
                            player.x--;


                        WASDupdate(pole, player, count, level);
                    }
                        else
                        {
                            if (e.KeyCode == Keys.D && CheckWallPlayerRight(pole, player) == true && CheckTwicePlayerRight(pole, player) == true)
                            {
                                RightBoxMove(pole, player);
                                if (pole[player.y, player.x + 1] != 5 && pole[player.y, player.x + 1] != 4) pole[player.y, player.x + 1] = 1; else pole[player.y, player.x + 1] = 6;//����� ������ ��������
                                if (pole[player.y, player.x] != 6) pole[player.y, player.x] = 0; else pole[player.y, player.x] = 4;
                                player.x++;
                          
                            WASDupdate(pole, player, count, level);
                        }








                            else
                            {

                            if (e.KeyCode == Keys.R)
                            {
                                GenPole(pole);


                                if (curlevel == 1) Level1(pole, player);
                                if (curlevel == 2) Level2(pole, player);
                                if (curlevel == 3) Level3(pole, player);
                            
                                for (int y = 0; y < 12; y++)
                                {
                                    for (int x = 0; x < 30; x++)
                                    {
                                      
                                        if (pole[y, x] == 0) { l[y, x].Image = Image.FromFile("Resources\\" + "\\0.jpg"); }
                                        if (pole[y, x] == 1) { l[y, x].Image = Image.FromFile("Resources\\" + "\\1.jpg"); }
                                        if (pole[y, x] == 2) { l[y, x].Image = Image.FromFile("Resources\\" + "\\2.jpg"); }
                                        if (pole[y, x] == 3) { l[y, x].Image = Image.FromFile("Resources\\" + "\\3.jpg"); }
                                        if (pole[y, x] == 4) { l[y, x].Image = Image.FromFile("Resources\\" + "\\4.jpg"); }
                                        if (pole[y, x] == 5) { l[y, x].Image = Image.FromFile("Resources\\" + "\\5.jpg"); }
                                        if (pole[y, x] == 6) { l[y, x].Image = Image.FromFile("Resources\\" + "\\6.jpg"); }
                                    }
                                }
                            }
                            else
                            {
                                if (e.KeyCode == Keys.Escape)
                                {
                                    Dele();
                                  Men();
                                }
                            }

                            }
                        }
                    }



                


            }
        }




        private void button1_Click(object sender, EventArgs e)
        {
            Dele();
            GenPole(pole);

            Level1(pole, player);


            Appea(pole);
                    
              
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Dele();
            GenPole(pole);
            Level2(pole, player);


            Appea(pole);


        }
        private void button3_Click(object sender, EventArgs e)
        {
            Dele();
            GenPole(pole);
            Level3(pole, player);



            Appea(pole);
        }


        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"W- �����; A- �����; S- ����; D- ������; R- ������������� �������; Esc- ����� ");
        }

        private void Form1_Load(object sender, EventArgs e)
        {






        }
        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}